package org.apache.spark.edu.wpi.dsrg.tardis.isax

/**
  * Created by leon on 9/13/17.
  */
object NodeType extends Enumeration with Serializable {
  type NodeType = Value
  val ROOT, STEM, LEAF, UNDEF = Value
}