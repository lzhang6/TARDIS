package org.apache.spark.edu.wpi.dsrg.tardis.utils

/**
  * Created by lzhang6 on 8/13/17.
  */

import org.apache.spark.edu.wpi.dsrg.tardis.configs.IdxCfg
import org.apache.spark.edu.wpi.dsrg.tardis.utils.Util.genZero
import org.apache.spark.internal.Logging

import scala.math._

/**
  * old version: SAX byte
  * new version: SAX int, more scalability
  */
object Ops extends Logging with Serializable {
  def cvtTsToIsaxHex(tsRecord: Array[Float], idxCfg: IdxCfg): String = {
    val tsPaa = cvtTsToPaa(tsRecord, idxCfg.step)
    val tsSax = cvtPaaToSAX(tsPaa, idxCfg.breakPoints)
    val tsIsaxHex = cvtSaxToIsaxHex(tsSax, idxCfg.startHrc, idxCfg.bitStep)
    tsIsaxHex
  }

  private[this] def cvtTsToPaa(tsRecord: Array[Float], step: Int): Array[Float] = {
    tsRecord.sliding(step, step).map(x => x.sum / x.length).toArray
  }

  private[this] def cvtPaaToSAX(tsPaa: Array[Float], BPs: Array[Float]): Array[Int] = {
    def convert(v: Float): Int = BPs.indexWhere(v < _)

    tsPaa.map(x => convert(x))
  }

  private[this] def cvtSaxToIsaxHex(tsSax: Array[Int], hrc: Int, bitStep: Int): String = {
    def cvtIntToBinStr(x: Int, hrc: Int): String = {
      val xs: String = x.toBinaryString
      if (xs.length < hrc)
        genZero(hrc - xs.length) + xs
      else xs
    }

    def cvtBinCharArrayToHexStr(v: Array[Char]): String = {
      val tmp = Integer.parseInt(v.mkString, 2).toHexString
      if (tmp.length < bitStep)
        genZero(bitStep - tmp.length) + tmp
      else tmp
    }

    tsSax
      .map(x => cvtIntToBinStr(x, hrc).toArray)
      .transpose
      .map(x => cvtBinCharArrayToHexStr(x))
      .mkString
  }

  def calDistance(aTs: Array[Float], bTs: Array[Float]): Double = {
    require(aTs.length == bTs.length, "aTs.length: %d == bTs.length: %d".format(aTs.length, bTs.length))
    Util.euclideanDistance(aTs, bTs)
  }

  def calPaaSaxLB(ndSax: String, ts: Array[Float], idxCfg: IdxCfg): Double = {
    val saxA = cvtSaxHexToDec(ndSax, idxCfg.bitStep)
    val tsPAA = cvtTsToPaa(ts, idxCfg.step)

    val hrc = ndSax.length / idxCfg.bitStep
    sqrt(idxCfg.tsLength / idxCfg.wordLength) * calPaaSaxDist(saxA, tsPAA, hrc)
  }

  def containSax(sax: String, saxNode: String): Boolean = {
    require(sax.length >= saxNode.length, "sax.length: %d >= saxNode.length: %d".format(sax.length, saxNode.length))
    sax.take(saxNode.length) == saxNode
  }

  def cvtSAXtoSpecHrc(sax: String, hrc: Int, bitStep: Int): String = {
    require(sax.length >= hrc * bitStep, "sax.length %d >= hrc*idxCfg.bitStep %d".format(sax.length, hrc * bitStep))
    sax.take(hrc * bitStep)
  }

  def cvtToAncestor(sax: String, bitStep: Int): String = {
    require(sax.length > bitStep, "sax.length: %d > idxCfg.bitStep: %d".format(sax.length, bitStep))
    sax.dropRight(bitStep)
  }

  def cvtSaxHexToDec(ndSax: String, bitStep: Int): List[Int] = {
    def cvtHexToBin(hexSax: String, len: Int): String = {
      val data = Integer.parseInt(hexSax, 16).toBinaryString
      val gap = len - data.length
      if (gap > 0) {
        Util.genZero(gap) + data
      } else data
    }

    val len = bitStep * 4

    val ndSaxHex = ndSax
      .sliding(bitStep, bitStep)
      .map(x => cvtHexToBin(x, len).sliding(1, 1).toArray)
      .toArray

    val result = ndSaxHex
      .transpose
      .map(elem => Integer.parseInt(elem.toList.mkString(""), 2))
      .toList
    result
  }

  def calPaaSaxDist(xsPaa: List[Int], ysSax: Array[Float], hrc: Int): Double = {
    require(xsPaa.length == ysSax.length, "calPaaSaxDist: xs.length:%d != ys.length: %d".format(xsPaa.length, ysSax.length))
    val cardinality = pow(2, hrc).toInt
    val BPs = BreakPoint(cardinality).clone()

    def paaSaxPairDis(x: Int, y: Float): Float = {
      val uL = BPs(x)
      val dL = if (x == 0) Float.NegativeInfinity else BPs(x - 1)

      val result = if (y > uL && uL != Float.NegativeInfinity) abs(uL - y)
      else if (dL > y && dL != Float.PositiveInfinity) abs(dL - y)
      else 0.0F

//      println("uL: %.2f, dL: %.2f, \t\tx: %d,y: %.1f, \t\t result: %.2f".format(uL,dL,x,y,result))
      result
    }

    sqrt((xsPaa zip ysSax).map { case (x, y) => pow(paaSaxPairDis(x, y), 2) }.sum)
  }
}