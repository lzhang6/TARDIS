package org.apache.spark.edu.wpi.dsrg.tardis.configs

import org.apache.spark.edu.wpi.dsrg.tardis.utils.Util
/**
  * Created by leon on 8/21/17.
  */
object rwCfg extends AbsConfig{
  val rwNumber: Long = configMap("rwNumber").toLong
  val rwLength: Int = configMap("rwLength").toInt
  val rwPartitionNbr: Int = calPartitionNbr()
  val rwSeed: Long = configMap("rwSeed").toLong
  val rwDirPath: String = configMap("rwDirPath")

  def printCfg() = Util.writeLog(this.toString, true, logPath)

  def getSaveHdfsPath(): String = {
    rwDirPath + "TS-" + rwNumber.toString + "-" + rwLength.toString + "-" + rwPartitionNbr.toString
  }

  override def toString: String = {
    ("\n==> Create RandomWalk Dataset Configuration" +
      "\n * rwNumber\t%d" +
      "\n * rwLength\t%d" +
      "\n * rwPartitionNbr\t%d" +
      "\n * blockSize\t%d" +
      "\n * rwSavePath\t%s").format(
      rwNumber,
      rwLength,
      rwPartitionNbr,
      blockSize,
      getSaveHdfsPath())
  }

  private def calPartitionNbr(rate:Double=1.05):Int={
    val totalSize = rwNumber*(rwLength * 4 + 8)*rate/(1024*1024)
    math.ceil(totalSize/this.blockSize).toInt
  }
}

