package org.apache.spark.edu.wpi.dsrg.tardis.isax

/**
  * Created by leon on 8/12/17.
  */

import org.apache.spark.Partitioner

class iSAXPartitioner(tree: iSAXTreeHex) extends Partitioner {
  override def numPartitions: Int = tree.getPartitionNumber()

  override def getPartition(key: Any): Int = {
    tree.getPId(key.toString)
  }

  override def equals(other: scala.Any): Boolean = other match {
    case temp: iSAXPartitioner => temp.numPartitions == numPartitions
    case _ => false
  }
}

class iSAXPartitionerSampling(tree: iSAXTreeHex) extends Partitioner {
  private val extraId = tree.getPartitionNumber()
  override def numPartitions: Int = extraId +1

  override def getPartition(key: Any): Int = {
    try{
      tree.getPId(key.toString)
    }catch {
      case e:Exception => extraId
    }
  }

  override def equals(other: scala.Any): Boolean = other match {
    case temp: iSAXPartitioner => temp.numPartitions == numPartitions
    case _ => false
  }
}
