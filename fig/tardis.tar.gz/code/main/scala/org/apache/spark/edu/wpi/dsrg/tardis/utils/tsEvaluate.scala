package org.apache.spark.edu.wpi.dsrg.tardis.utils

import org.apache.spark.SparkContext
import org.apache.spark.edu.wpi.dsrg.tardis.configs.{IdxCfg, idxConfig}
import org.apache.spark.internal.Logging
import org.apache.spark.storage.StorageLevel
/**
  * Created by leon on 10/30/17.
  */
object tsEvaluate extends Logging {
  def apply(sc: SparkContext): Unit = {
    idxConfig.printCfg()
    val idxCfg = idxConfig.generateIdxCfg()

    val eq = new tsEvaluate(sc)
    eq.getTsInfo(idxCfg)
  }
}

class tsEvaluate (sc: SparkContext) extends Logging with Serializable{
  def getTsInfo(idxCfg: IdxCfg): Unit ={
    val tsRdd = sc.objectFile[(Long, Array[Float])](idxCfg.tsFileName)
    var newrdd = tsRdd.map { case (id, ts) =>Ops.cvtTsToIsaxHex(ts, idxCfg)}
      .distinct()
      .persist(StorageLevel.MEMORY_AND_DISK)

    writeLog(" sax_7 \t%d".format(newrdd.count()))

    val bitStep = 2

    for (i<- 0 to 4){
      newrdd = newrdd.map(sax => sax.dropRight(bitStep))//Ops.cvtToAncestor(sax,bitStep))
        .distinct().persist(StorageLevel.MEMORY_AND_DISK)
      val nbr = newrdd.count()
      writeLog(" sax_%d \t%d".format(6-i,nbr))
    }
  }

  private def writeLog(content: String): Unit = {
    Util.writeLog(content, true, idxConfig.logPath)
  }
}

