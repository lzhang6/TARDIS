package org.apache.spark.edu.wpi.dsrg.tardis

import org.apache.spark.SparkContext
import org.apache.spark.edu.wpi.dsrg.tardis.configs.rwCfg
import org.apache.spark.edu.wpi.dsrg.tardis.utils.Util
import org.apache.spark.internal.Logging
import org.apache.spark.mllib.random.RandomRDDs
import org.apache.spark.rdd._

/**
  * Created by leon on 7/6/17.
  */
object RandWalkTsCreater extends Logging {
  def generateTsAndSave(sc: SparkContext): Unit = {
    rwCfg.printCfg()

    val tsRdd = generateTsRdd(sc,
      rwCfg.rwNumber,
      rwCfg.rwLength,
      rwCfg.rwPartitionNbr,
      rwCfg.rwSeed)

    try {
      val savePath = rwCfg.getSaveHdfsPath()
      tsRdd.saveAsObjectFile(savePath)
      writeLog(("==> Random Walk generate Time series successfully! %s").format(savePath))
    } catch {
      case e: Exception => logError(e.toString)
        System.exit(0)
    }
  }

  def generateTsRdd(sc: SparkContext, nbr: Long, length: Int, partitionNbr: Int, seed: Long): RDD[(Long, Array[Float])] = {
    RandomRDDs.normalVectorRDD(sc, nbr, length, partitionNbr, seed)
      .map(x => convert(x.toArray))
      .map(x => normalize(x))
      .zipWithUniqueId()
      .map { case (x, y) => (y, x) }
  }

  private def convert(ts: Array[Double]): Array[Float] = {
    val tn = ts.map(x => x.toFloat)
    for (i <- 1 to tn.length - 1) {
      tn(i) = tn(i - 1) + tn(i)
    }
    tn
  }

  private def normalize(ts: Array[Float]): Array[Float] = {
    val count = ts.length
    val mean = ts.sum / count
    val variance = ts.map(x => math.pow(x - mean, 2)).sum / (count - 1)
    val std = math.sqrt(variance)
    ts.map(x => ((x - mean) / std).toFloat)
  }

  def writeLog(content:String): Unit ={
    Util.writeLog(content, true, rwCfg.logPath)
  }
}